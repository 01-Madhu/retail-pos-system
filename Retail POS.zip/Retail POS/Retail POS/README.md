# Retail POS & Inventory Manager

## Project Overview
Retail POS & Inventory Manager is a Windows desktop application (WinForms) designed for small to medium retail shops. It provides offline-first functionality for product management, point-of-sale (POS) transactions, inventory tracking, supplier/customer records, reporting, and database backup/restore.

## Features Summary
- User login with role-based access (Admin, Manager, Cashier)
- Product management (CRUD) with stock tracking and low-stock alerts
- POS (sales) interface supporting SKU/barcode entry, cart management, discounts, tax, and multiple payment methods
- Sales and inventory reporting with CSV export
- Backup and restore of local SQLite database (`retail.db`)
- Simple modular structure (Database helper, Models, Utils)

## System Requirements
- Visual Studio 2022 or later (recommended) or `dotnet` CLI
- .NET 8.0 (project targets `net8.0-windows`) or .NET Framework 4.8 (alternate target possible)
- Microsoft.Data.Sqlite NuGet package (already referenced in the project)
- Windows 10 or higher

## Setup & Run Instructions
1. Clone or extract the project folder to your machine.
2. Open the solution/project (`Retail POS/Retail POS.csproj`) in Visual Studio or restore packages and build with `dotnet build`.
3. Run the application. On first run the app creates `Database/retail.db` and executes `Database/create_db.sql` to create tables and seed sample data.
4. Default credentials:
   - Username: `admin`
   - Password: `1234`

Notes:
- `create_db.sql` is included and is executed automatically by the `LoginForm` if present in the application output. The `DatabaseHelper` ensures the `Database` folder and `retail.db` file exist.

## Folder Structure
- `Database/` - Database helper and SQL script (`create_db.sql`), `retail.db` is created here at runtime
- `Models/` - POCO classes mapping directly to DB tables (User, Product, Sale, SaleItem, Customer, Supplier)
- `Utils/` - Utility helpers (HashHelper for SHA256, BackupHelper for backup/restore)
- `LoginForm.cs` - Login UI and initialization logic
- `MainDashboard.cs` - Main menu and navigation (role-based access)
- `ProductForm.cs`, `POSForm.cs`, `CustomerForm.cs`, `SupplierForm.cs`, `ReportForm.cs` - Feature forms
- `Program.cs` - Application entry point

## Known Limitations & Future Improvements
- User management UI (create/remove users) is not yet implemented � only seeded admin exists.
- Reporting is basic; add filtering by product/cashier and PDF export in future.
- No per-user salted password hashes yet (HashHelper currently computes plain SHA256). TODO: add per-user salt.
- No printing integration beyond PrintPreview; add direct printer support and receipt templates.
- No unit tests included; consider adding automated tests for data access and business logic.

## Author
Madhushan Sangaralingam (E2410438)

## License
Educational / Academic Use Only. Not for commercial distribution without permission.
