-- ===========================================================
-- SQL Server create_db.sql for RetailPOS
-- Complete schema and seed data for the application
-- ===========================================================

-- Users table
IF OBJECT_ID('users', 'U') IS NULL
CREATE TABLE users (
    id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(100) NOT NULL UNIQUE,
    password_hash NVARCHAR(256) NOT NULL,
    role NVARCHAR(50) NOT NULL
);

-- Default Admin user (password: 1234, SHA256 hash)
IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin')
INSERT INTO users (username, password_hash, role)
VALUES ('admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'Admin');

-- Products table
IF OBJECT_ID('products', 'U') IS NULL
CREATE TABLE products (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    category NVARCHAR(100),
    sku NVARCHAR(50) UNIQUE,
    barcode NVARCHAR(50),
    price DECIMAL(18,2) NOT NULL,
    stock_qty INT NOT NULL DEFAULT 0,
    low_stock_alert INT NOT NULL DEFAULT 5
);

-- Sample products
IF NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SKU001')
INSERT INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
VALUES ('Soap Bar', 'Daily', 'SKU001', '', 60.00, 50, 5);
IF NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SKU002')
INSERT INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
VALUES ('Rice 5kg', 'Grocery', 'SKU002', '', 650.00, 20, 5);
IF NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SKU003')
INSERT INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
VALUES ('Tea Pack', 'Beverages', 'SKU003', '', 250.00, 35, 5);
IF NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SKU004')
INSERT INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
VALUES ('Notebook A4', 'Stationary', 'SKU004', '', 120.00, 40, 5);
IF NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SKU005')
INSERT INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
VALUES ('Blue Pen', 'Stationary', 'SKU005', '', 25.00, 200, 10);

-- Sales table
IF OBJECT_ID('sales', 'U') IS NULL
CREATE TABLE sales (
    id INT IDENTITY(1,1) PRIMARY KEY,
    datetime DATETIME NOT NULL,
    total DECIMAL(18,2) NOT NULL,
    discount DECIMAL(18,2) DEFAULT 0,
    tax DECIMAL(18,2) DEFAULT 0,
    final_amount DECIMAL(18,2) NOT NULL,
    user_id INT FOREIGN KEY REFERENCES users(id)
);

-- Sale items table
IF OBJECT_ID('sale_items', 'U') IS NULL
CREATE TABLE sale_items (
    id INT IDENTITY(1,1) PRIMARY KEY,
    sale_id INT FOREIGN KEY REFERENCES sales(id),
    product_id INT FOREIGN KEY REFERENCES products(id),
    quantity INT,
    subtotal DECIMAL(18,2)
);

-- Customers table
IF OBJECT_ID('customers', 'U') IS NULL
CREATE TABLE customers (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100),
    phone NVARCHAR(20),
    email NVARCHAR(100),
    loyalty_points INT DEFAULT 0
);

-- Suppliers table
IF OBJECT_ID('suppliers', 'U') IS NULL
CREATE TABLE suppliers (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100),
    contact NVARCHAR(100),
    email NVARCHAR(100),
    address NVARCHAR(200)
);

-- Purchases table
IF OBJECT_ID('purchases', 'U') IS NULL
CREATE TABLE purchases (
    id INT IDENTITY(1,1) PRIMARY KEY,
    supplier_id INT FOREIGN KEY REFERENCES suppliers(id),
    date DATETIME,
    total DECIMAL(18,2)
);

-- Purchase items table
IF OBJECT_ID('purchase_items', 'U') IS NULL
CREATE TABLE purchase_items (
    id INT IDENTITY(1,1) PRIMARY KEY,
    purchase_id INT FOREIGN KEY REFERENCES purchases(id),
    product_id INT FOREIGN KEY REFERENCES products(id),
    quantity INT,
    cost DECIMAL(18,2)
);

-- Indexes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_products_sku')
CREATE INDEX idx_products_sku ON products(sku);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_products_barcode')
CREATE INDEX idx_products_barcode ON products(barcode);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_sales_datetime')
CREATE INDEX idx_sales_datetime ON sales(datetime);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_sale_items_sale_id')
CREATE INDEX idx_sale_items_sale_id ON sale_items(sale_id);

-- ===========================================================
-- End of SQL Server create_db.sql
-- ===========================================================