using System;
using System.Data;
using System.IO;
using Microsoft.Data.Sqlite;

namespace RetailPOS.Database
{
    public static class DatabaseHelper
    {
        public static string DefaultConnectionString { get; set; } = "Data Source=retail.db;Cache=Shared;";
        private static readonly string DatabaseFolderName = "Database";

        public static void InitializeDatabase()
        {
            try
            {
                string baseDir = AppContext.BaseDirectory;
                string dbFolder = Path.Combine(baseDir, DatabaseFolderName);

                if (!Directory.Exists(dbFolder))
                    Directory.CreateDirectory(dbFolder);

                string dbPath = Path.Combine(dbFolder, "retail.db");

                if (!File.Exists(dbPath))
                {
                    CreateDatabaseSchema();
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to initialize database", ex);
            }
        }

        private static void CreateDatabaseSchema()
        {
            using var conn = GetConnection();

            // Users table
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL
                )");

            // Insert default admin user (password: 1234)
            ExecuteNonQuery(conn, @"
                INSERT OR IGNORE INTO users (username, password_hash, role)
                VALUES ('admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'Admin')");

            // Products table
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    category TEXT,
                    sku TEXT UNIQUE,
                    barcode TEXT,
                    price REAL NOT NULL,
                    stock_qty INTEGER NOT NULL DEFAULT 0,
                    low_stock_alert INTEGER NOT NULL DEFAULT 5
                )");

            // Insert sample products
            ExecuteNonQuery(conn, @"
                INSERT OR IGNORE INTO products (name, category, sku, barcode, price, stock_qty, low_stock_alert)
                VALUES 
                ('Soap Bar', 'Daily', 'SKU001', '', 60.00, 50, 5),
                ('Rice 5kg', 'Grocery', 'SKU002', '', 650.00, 20, 5),
                ('Tea Pack', 'Beverages', 'SKU003', '', 250.00, 35, 5),
                ('Notebook A4', 'Stationary', 'SKU004', '', 120.00, 40, 5),
                ('Blue Pen', 'Stationary', 'SKU005', '', 25.00, 200, 10)");

            // Sales table
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    datetime TEXT NOT NULL,
                    total REAL NOT NULL,
                    discount REAL DEFAULT 0,
                    tax REAL DEFAULT 0,
                    final_amount REAL NOT NULL,
                    user_id INTEGER
                )");

            // Sale items table
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS sale_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sale_id INTEGER NOT NULL,
                    product_id INTEGER,
                    quantity INTEGER,
                    subtotal REAL
                )");

            // Customers table
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    phone TEXT,
                    email TEXT,
                    loyalty_points INTEGER DEFAULT 0
                )");
        }

        public static SqliteConnection GetConnection()
        {
            var connection = new SqliteConnection(DefaultConnectionString);
            connection.Open();
            return connection;
        }

        private static void ExecuteNonQuery(SqliteConnection connection, string sql)
        {
            using var command = connection.CreateCommand();
            command.CommandText = sql;
            command.ExecuteNonQuery();
        }

        public static int ExecuteNonQuery(string sql, params SqliteParameter[] parameters)
        {
            using var conn = GetConnection();
            using var command = conn.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddRange(parameters);
            return command.ExecuteNonQuery();
        }

        public static object ExecuteScalar(string sql, params SqliteParameter[] parameters)
        {
            using var conn = GetConnection();
            using var command = conn.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddRange(parameters);
            return command.ExecuteScalar();
        }

        public static DataTable ExecuteQuery(string sql, params SqliteParameter[] parameters)
        {
            using var conn = GetConnection();
            using var command = conn.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddRange(parameters);

            using var reader = command.ExecuteReader();
            var dataTable = new DataTable();
            dataTable.Load(reader);
            return dataTable;
        }
    }
}