using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace RetailPOS.Utils
{
    /// <summary>
    /// Centralized UI styling helpers and constants for the application.
    /// Use these helpers from forms to apply a consistent modern look.
    /// </summary>
    public static class UiStyles
    {
        // Color palette
        public static readonly Color Background = ColorTranslator.FromHtml("#f5f5f5"); // light gray
        public static readonly Color Header = ColorTranslator.FromHtml("#2c3e50"); // dark blue-gray
        public static readonly Color Button = ColorTranslator.FromHtml("#3498db"); // blue
        public static readonly Color ButtonHover = ColorTranslator.FromHtml("#2980b9"); // darker blue
        public static readonly Color LabelText = ColorTranslator.FromHtml("#2c3e50"); // dark
        public static readonly Color GridAltRow = ColorTranslator.FromHtml("#ecf0f1"); // alternate
        public static readonly Color GridHeader = ColorTranslator.FromHtml("#34495e"); // header

        // Fonts
        public static readonly Font FontRegular = new Font("Segoe UI", 10F, FontStyle.Regular);
        public static readonly Font FontHeading = new Font("Segoe UI", 14F, FontStyle.Bold);

        /// <summary>
        /// Applies modern button styling including flat style, colors and rounded corners.
        /// </summary>
        public static void StyleButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = Button;
            btn.ForeColor = Color.White;
            btn.Font = FontRegular;
            btn.Padding = new Padding(8, 6, 8, 6);
            btn.Cursor = Cursors.Hand;

            // Hover effect
            btn.MouseEnter += (s, e) => btn.BackColor = ButtonHover;
            btn.MouseLeave += (s, e) => btn.BackColor = Button;

            // Rounded corners: set region on resize
            btn.Resize += (s, e) =>
            {
                var b = s as Button;
                if (b.Width > 0 && b.Height > 0)
                {
                    using (var gp = new GraphicsPath())
                    {
                        int radius = 8;
                        gp.AddArc(new Rectangle(0, 0, radius, radius), 180, 90);
                        gp.AddArc(new Rectangle(b.Width - radius, 0, radius, radius), 270, 90);
                        gp.AddArc(new Rectangle(b.Width - radius, b.Height - radius, radius, radius), 0, 90);
                        gp.AddArc(new Rectangle(0, b.Height - radius, radius, radius), 90, 90);
                        gp.CloseAllFigures();
                        b.Region = new Region(gp);
                    }
                }
            };
        }

        /// <summary>
        /// Styles a panel as a card with white background and subtle border for modern appearance.
        /// </summary>
        public static void StyleCard(Panel panel)
        {
            panel.BackColor = Color.White;
            panel.Padding = new Padding(10);
            panel.Margin = new Padding(8);
            panel.BorderStyle = BorderStyle.FixedSingle;
        }

        /// <summary>
        /// Styles a DataGridView to use the app theme: header, alternate rows and fonts.
        /// </summary>
        public static void StyleDataGrid(DataGridView dgv)
        {
            dgv.EnableHeadersVisualStyles = false;
            dgv.BackgroundColor = Background;
            dgv.BorderStyle = BorderStyle.None;
            dgv.GridColor = Color.LightGray;
            dgv.RowHeadersVisible = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.DefaultCellStyle.Font = FontRegular;
            dgv.ColumnHeadersDefaultCellStyle.Font = FontRegular;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = GridHeader;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = GridAltRow;
            dgv.DefaultCellStyle.ForeColor = Color.Black;
        }
    }
}
