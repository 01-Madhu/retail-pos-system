using System;
using System.IO;
using System.Windows.Forms;

namespace RetailPOS.Utils
{
    /// <summary>
    /// Provides simple backup and restore helpers for the local SQLite database file.
    /// </summary>
    public static class BackupHelper
    {
        /// <summary>
        /// Creates a timestamped backup copy of the Database/retail.db file into a Backups folder
        /// located in the application base directory. Shows MessageBoxes on success or failure.
        /// </summary>
        public static void BackupDatabase()
        {
            try
            {
                string baseDir = AppContext.BaseDirectory;
                string dbFolder = Path.Combine(baseDir, "Database");
                string dbFile = Path.Combine(dbFolder, "retail.db");

                if (!File.Exists(dbFile))
                {
                    MessageBox.Show($"Database file not found: {dbFile}", "Backup Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string backupsFolder = Path.Combine(baseDir, "Backups");
                if (!Directory.Exists(backupsFolder))
                {
                    Directory.CreateDirectory(backupsFolder);
                }

                // Timestamp format: yyyyMMdd_HHmmss
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string destFileName = $"retail_{timestamp}.db";
                string destPath = Path.Combine(backupsFolder, destFileName);

                // Copy the database file to the backups folder. This will open and close streams internally.
                File.Copy(dbFile, destPath);

                MessageBox.Show($"Backup created: {destPath}", "Backup Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to create backup: {ex.Message}", "Backup Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Restores the database from a selected backup file. Prompts the user to choose a .db file
        /// from the Backups folder, confirms the action, and replaces the current Database/retail.db file.
        /// Tries to handle file-in-use errors by forcing GC and retrying once.
        /// </summary>
        public static void RestoreDatabase()
        {
            try
            {
                string baseDir = AppContext.BaseDirectory;
                string backupsFolder = Path.Combine(baseDir, "Backups");
                string dbFolder = Path.Combine(baseDir, "Database");
                string dbFile = Path.Combine(dbFolder, "retail.db");

                if (!Directory.Exists(backupsFolder))
                {
                    MessageBox.Show("No backups folder found.", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                using (var ofd = new OpenFileDialog())
                {
                    ofd.InitialDirectory = backupsFolder;
                    ofd.Filter = "SQLite DB files (*.db)|*.db|All files (*.*)|*.*";
                    ofd.Title = "Select backup file to restore";

                    if (ofd.ShowDialog() != DialogResult.OK)
                    {
                        MessageBox.Show("Restore cancelled.", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    string selected = ofd.FileName;

                    var confirm = MessageBox.Show($"Are you sure you want to restore the database from:\n{selected}\nThis will replace the current database file.", "Confirm Restore", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (confirm != DialogResult.Yes)
                    {
                        MessageBox.Show("Restore cancelled.", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    try
                    {
                        // Ensure destination folder exists
                        if (!Directory.Exists(dbFolder)) Directory.CreateDirectory(dbFolder);

                        // If target file exists, try to overwrite. If file is locked, attempt a GC and retry once.
                        try
                        {
                            File.Copy(selected, dbFile, overwrite: true);
                        }
                        catch (IOException ioex)
                        {
                            // Attempt to release any unmanaged resources that might be holding the file
                            GC.Collect();
                            GC.WaitForPendingFinalizers();

                            try
                            {
                                File.Copy(selected, dbFile, overwrite: true);
                            }
                            catch (IOException)
                            {
                                MessageBox.Show($"Failed to restore database because the file is in use. Close the application or any tool using the database and try again.\n\n{ioex.Message}", "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        MessageBox.Show("Database restored successfully. Restart the application to ensure changes take effect.", "Restore Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to restore database: {ex.Message}", "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to perform restore: {ex.Message}", "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
