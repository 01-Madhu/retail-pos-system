using System;
using System.Drawing;
using System.Windows.Forms;

namespace RetailPOS
{
    public class ProductDialog : Form
    {
        public Product Product { get; private set; }
        private TextBox txtName, txtCategory, txtPrice, txtStock, txtLowStock;
        private Button btnOK, btnCancel;
        private int _id;

        public ProductDialog(int id = 0, string name = "", string category = "", decimal price = 0, int stock = 0, int lowStock = 5)
        {
            _id = id;
            InitializeComponent();
            txtName.Text = name;
            txtCategory.Text = category;
            txtPrice.Text = price.ToString();
            txtStock.Text = stock.ToString();
            txtLowStock.Text = lowStock.ToString();
        }

        private void InitializeComponent()
        {
            this.Text = _id == 0 ? "Add Product" : "Edit Product";
            this.Size = new Size(350, 320);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;

            var lblName = new Label { Text = "Name", Location = new Point(20, 20), AutoSize = true };
            txtName = new TextBox { Location = new Point(120, 18), Width = 180 };

            var lblCategory = new Label { Text = "Category", Location = new Point(20, 60), AutoSize = true };
            txtCategory = new TextBox { Location = new Point(120, 58), Width = 180 };

            var lblPrice = new Label { Text = "Price", Location = new Point(20, 100), AutoSize = true };
            txtPrice = new TextBox { Location = new Point(120, 98), Width = 180 };

            var lblStock = new Label { Text = "Stock Qty", Location = new Point(20, 140), AutoSize = true };
            txtStock = new TextBox { Location = new Point(120, 138), Width = 180 };

            var lblLowStock = new Label { Text = "Low Stock Alert", Location = new Point(20, 180), AutoSize = true };
            txtLowStock = new TextBox { Location = new Point(120, 178), Width = 180 };

            btnOK = new Button { Text = "OK", Location = new Point(120, 230), Width = 80 };
            btnOK.Click += BtnOK_Click;
            btnCancel = new Button { Text = "Cancel", Location = new Point(220, 230), Width = 80 };
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(lblCategory);
            this.Controls.Add(txtCategory);
            this.Controls.Add(lblPrice);
            this.Controls.Add(txtPrice);
            this.Controls.Add(lblStock);
            this.Controls.Add(txtStock);
            this.Controls.Add(lblLowStock);
            this.Controls.Add(txtLowStock);
            this.Controls.Add(btnOK);
            this.Controls.Add(btnCancel);
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Product name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            if (!decimal.TryParse(txtPrice.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Price must be a positive number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Focus();
                return;
            }
            if (!int.TryParse(txtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("Stock must be a positive integer.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtStock.Focus();
                return;
            }
            if (!int.TryParse(txtLowStock.Text, out int lowStock) || lowStock < 0)
            {
                MessageBox.Show("Low stock alert must be a positive integer.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLowStock.Focus();
                return;
            }
            Product = new Product
            {
                Id = _id,
                Name = txtName.Text.Trim(),
                Category = txtCategory.Text.Trim(),
                Price = price,
                StockQty = stock,
                LowStockAlert = lowStock
            };
            this.DialogResult = DialogResult.OK;
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public decimal Price { get; set; }
        public int StockQty { get; set; }
        public int LowStockAlert { get; set; }
    }
}
