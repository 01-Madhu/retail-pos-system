using System;
using System.Drawing;
using System.Windows.Forms;

namespace RetailPOS
{
    public class MainDashboard : Form
    {
        private int _userId;
        private string _username;
        private string _role;

        private Panel sidebar;
        private Panel mainPanel;

        public MainDashboard(int userId, string username, string role)
        {
            _userId = userId;
            _username = username;
            _role = role;

            InitializeComponent();
            ShowDashboardOverview();
        }

        private void InitializeComponent()
        {
            this.Text = "Retail POS - Dashboard (" + _role + ")";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.FormClosing += (s, e) => Application.Exit();

            // Header
            var header = new Panel
            {
                Size = new Size(1000, 50),
                Location = new Point(0, 0),
                BackColor = Color.FromArgb(0, 122, 204)
            };

            var lblWelcome = new Label
            {
                Text = "Welcome, " + _username + " (" + _role + ")",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblDateTime = new Label
            {
                Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy"),
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.White,
                Location = new Point(700, 20),
                AutoSize = true
            };

            // Sidebar
            sidebar = new Panel
            {
                Size = new Size(200, 550),
                Location = new Point(0, 50),
                BackColor = Color.FromArgb(52, 58, 64)
            };

            // Main content area
            mainPanel = new Panel
            {
                Size = new Size(800, 550),
                Location = new Point(200, 50),
                BackColor = Color.White
            };

            CreateSidebarButtons();

            header.Controls.Add(lblWelcome);
            header.Controls.Add(lblDateTime);
            this.Controls.Add(header);
            this.Controls.Add(sidebar);
            this.Controls.Add(mainPanel);
        }

        private void CreateSidebarButtons()
        {
            string[] buttons = { "Dashboard", "Point of Sale", "Products", "Customers", "Sales Report", "Backup/Restore", "Logout" };
            string[] tags = { "dashboard", "pos", "products", "customers", "reports", "backup", "logout" };

            int yPos = 20;
            for (int i = 0; i < buttons.Length; i++)
            {
                var button = new Button
                {
                    Text = buttons[i],
                    Tag = tags[i],
                    Size = new Size(180, 40),
                    Location = new Point(10, yPos),
                    BackColor = Color.FromArgb(73, 80, 87),
                    ForeColor = Color.White,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Font = new Font("Segoe UI", 10)
                };
                button.Click += SidebarButton_Click;

                sidebar.Controls.Add(button);
                yPos += 50;
            }
        }

        private void SidebarButton_Click(object sender, EventArgs e)
        {
            var button = (Button)sender;
            string tag = button.Tag.ToString();

            switch (tag)
            {
                case "dashboard":
                    ShowDashboardOverview();
                    break;
                case "pos":
                    ShowPOS();
                    break;
                case "products":
                    ShowProducts();
                    break;
                case "customers":
                    ShowCustomers();
                    break;
                case "reports":
                    ShowReports();
                    break;
                case "backup":
                    ShowBackup();
                    break;
                case "logout":
                    Logout();
                    break;
            }
        }

        private void ShowDashboardOverview()
        {
            mainPanel.Controls.Clear();

            var title = new Label
            {
                Text = "Dashboard Overview",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            // Create stats panels
            var statsPanel = new Panel
            {
                Location = new Point(20, 70),
                Size = new Size(750, 120)
            };

            string[] titles = { "Total Products", "Today Sales", "Low Stock", "Customers" };
            string[] values = { "45", "GHS 1,250.00", "3", "128" };
            Color[] colors =
            {
                Color.FromArgb(40, 167, 69),
                Color.FromArgb(0, 123, 255),
                Color.FromArgb(255, 193, 7),
                Color.FromArgb(111, 66, 193)
            };

            int xPos = 0;
            for (int i = 0; i < titles.Length; i++)
            {
                var statPanel = CreateStatPanel(titles[i], values[i], colors[i], xPos);
                statsPanel.Controls.Add(statPanel);
                xPos += 185;
            }

            // Recent activity
            var activityPanel = new Panel
            {
                Location = new Point(20, 220),
                Size = new Size(750, 300),
                BorderStyle = BorderStyle.FixedSingle
            };

            var activityTitle = new Label
            {
                Text = "Recent Sales",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true
            };

            var dataGrid = new DataGridView
            {
                Location = new Point(10, 50),
                Size = new Size(730, 240),
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false
            };

            dataGrid.Columns.Add("Date", "Date");
            dataGrid.Columns.Add("Amount", "Amount");
            dataGrid.Columns.Add("Items", "Items");
            dataGrid.Columns.Add("Status", "Status");

            // Sample data
            dataGrid.Rows.Add("2024-01-15 10:30", "GHS 250.00", "3 items", "Completed");
            dataGrid.Rows.Add("2024-01-15 09:15", "GHS 180.50", "2 items", "Completed");
            dataGrid.Rows.Add("2024-01-14 16:45", "GHS 420.75", "5 items", "Completed");

            activityPanel.Controls.Add(activityTitle);
            activityPanel.Controls.Add(dataGrid);

            mainPanel.Controls.Add(title);
            mainPanel.Controls.Add(statsPanel);
            mainPanel.Controls.Add(activityPanel);
        }

        private Panel CreateStatPanel(string title, string value, Color color, int xPos)
        {
            var panel = new Panel
            {
                Size = new Size(175, 100),
                Location = new Point(xPos, 0),
                BackColor = color,
                ForeColor = Color.White
            };

            var lblValue = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                Location = new Point(10, 30),
                AutoSize = true,
                ForeColor = Color.White
            };

            var lblTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 10),
                Location = new Point(10, 70),
                AutoSize = true,
                ForeColor = Color.White
            };

            panel.Controls.Add(lblValue);
            panel.Controls.Add(lblTitle);

            return panel;
        }

        private void ShowPOS()
        {
            mainPanel.Controls.Clear();
            var posForm = new POSForm();
            posForm.TopLevel = false;
            posForm.FormBorderStyle = FormBorderStyle.None;
            posForm.Dock = DockStyle.Fill;
            mainPanel.Controls.Add(posForm);
            posForm.Show();
        }

        private void ShowProducts()
        {
            mainPanel.Controls.Clear();
            var productsForm = new ProductForm();
            productsForm.TopLevel = false;
            productsForm.FormBorderStyle = FormBorderStyle.None;
            productsForm.Dock = DockStyle.Fill;
            mainPanel.Controls.Add(productsForm);
            productsForm.Show();
        }

        private void ShowCustomers()
        {
            mainPanel.Controls.Clear();
            mainPanel.Controls.Add(new Label
            {
                Text = "Customers Management - Coming Soon",
                Font = new Font("Segoe UI", 16),
                Location = new Point(50, 50),
                AutoSize = true
            });
        }

        private void ShowReports()
        {
            mainPanel.Controls.Clear();
            var reportsForm = new ReportForm(_role);
            reportsForm.TopLevel = false;
            reportsForm.FormBorderStyle = FormBorderStyle.None;
            reportsForm.Dock = DockStyle.Fill;
            mainPanel.Controls.Add(reportsForm);
            reportsForm.Show();
        }

        private void ShowBackup()
        {
            mainPanel.Controls.Clear();
            mainPanel.Controls.Add(new Label
            {
                Text = "Backup & Restore - Coming Soon",
                Font = new Font("Segoe UI", 16),
                Location = new Point(50, 50),
                AutoSize = true
            });
        }

        private void Logout()
        {
            var result = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Hide();
                var loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
    }
}