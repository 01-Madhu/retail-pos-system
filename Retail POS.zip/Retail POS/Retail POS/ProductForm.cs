using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using RetailPOS.Database;

namespace RetailPOS
{
    public class ProductForm : Form
    {
        private DataGridView dataGrid;
        private Button btnAdd, btnEdit, btnDelete;

        public ProductForm()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void InitializeComponent()
        {
            this.Text = "Product Management";
            this.BackColor = Color.White;

            var title = new Label
            {
                Text = "Product Management",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            dataGrid = new DataGridView
            {
                Location = new Point(20, 70),
                Size = new Size(700, 400),
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            dataGrid.Columns.Add("ID", "ID");
            dataGrid.Columns.Add("Name", "Product Name");
            dataGrid.Columns.Add("Category", "Category");
            dataGrid.Columns.Add("Price", "Price");
            dataGrid.Columns.Add("Stock", "Stock");
            dataGrid.Columns.Add("Status", "Status");

            btnAdd = new Button
            {
                Text = "Add Product",
                Location = new Point(20, 490),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10)
            };
            btnAdd.Click += BtnAdd_Click;

            btnEdit = new Button
            {
                Text = "Edit Product",
                Location = new Point(150, 490),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(255, 193, 7),
                ForeColor = Color.Black,
                Font = new Font("Segoe UI", 10)
            };
            btnEdit.Click += BtnEdit_Click;

            btnDelete = new Button
            {
                Text = "Delete Product",
                Location = new Point(280, 490),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(220, 53, 69),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10)
            };
            btnDelete.Click += BtnDelete_Click;

            this.Controls.Add(title);
            this.Controls.Add(dataGrid);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnEdit);
            this.Controls.Add(btnDelete);
        }

        private void LoadProducts()
        {
            try
            {
                dataGrid.Rows.Clear();
                var dt = DatabaseHelper.ExecuteQuery("SELECT id, name, category, price, stock_qty, low_stock_alert FROM products");
                foreach (System.Data.DataRow row in dt.Rows)
                {
                    int stock = Convert.ToInt32(row["stock_qty"]);
                    int low = Convert.ToInt32(row["low_stock_alert"]);
                    string status = stock < low ? "Low Stock" : "In Stock";
                    dataGrid.Rows.Add(row["id"], row["name"], row["category"], row["price"], stock, status);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load products: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var dialog = new ProductDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var p = dialog.Product;
                    var sql = "INSERT INTO products (name, category, price, stock_qty, low_stock_alert) VALUES (@name, @cat, @price, @stock, @low)";
                    var parameters = new[]
                    {
                        new SqliteParameter("@name", p.Name),
                        new SqliteParameter("@cat", p.Category),
                        new SqliteParameter("@price", p.Price),
                        new SqliteParameter("@stock", p.StockQty),
                        new SqliteParameter("@low", p.LowStockAlert)
                    };
                    DatabaseHelper.ExecuteNonQuery(sql, parameters);
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to add product: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a product to edit.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var row = dataGrid.SelectedRows[0];
            var dialog = new ProductDialog(
                Convert.ToInt32(row.Cells["ID"].Value),
                Convert.ToString(row.Cells["Name"].Value),
                Convert.ToString(row.Cells["Category"].Value),
                Convert.ToDecimal(row.Cells["Price"].Value),
                Convert.ToInt32(row.Cells["Stock"].Value),
                row.Cells["Status"].Value.ToString() == "Low Stock" ? 5 : 0 // fallback
            );
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var p = dialog.Product;
                    var sql = "UPDATE products SET name=@name, category=@cat, price=@price, stock_qty=@stock, low_stock_alert=@low WHERE id=@id";
                    var parameters = new[]
                    {
                        new SqliteParameter("@name", p.Name),
                        new SqliteParameter("@cat", p.Category),
                        new SqliteParameter("@price", p.Price),
                        new SqliteParameter("@stock", p.StockQty),
                        new SqliteParameter("@low", p.LowStockAlert),
                        new SqliteParameter("@id", p.Id)
                    };
                    DatabaseHelper.ExecuteNonQuery(sql, parameters);
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to update product: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a product to delete.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var row = dataGrid.SelectedRows[0];
            int id = Convert.ToInt32(row.Cells["ID"].Value);
            if (MessageBox.Show("Are you sure you want to delete this product?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    var sql = "DELETE FROM products WHERE id=@id";
                    var param = new SqliteParameter("@id", id);
                    DatabaseHelper.ExecuteNonQuery(sql, param);
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to delete product: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}