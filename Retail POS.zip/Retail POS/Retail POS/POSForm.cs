using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using RetailPOS.Database;

namespace RetailPOS
{
    public partial class POSForm : Form
    {
        private TextBox txtBarcode;
        private Button btnAdd;
        private DataGridView cartGrid;
        private Button btnCheckout;

        public POSForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Point of Sale";
            this.BackColor = Color.White;

            var title = new Label
            {
                Text = "Point of Sale",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            var scanPanel = new Panel
            {
                Location = new Point(20, 70),
                Size = new Size(600, 50),
                BorderStyle = BorderStyle.FixedSingle
            };

            txtBarcode = new TextBox
            {
                Location = new Point(10, 10),
                Size = new Size(400, 30),
                Font = new Font("Segoe UI", 12),
                PlaceholderText = "Scan barcode or enter product code..."
            };

            btnAdd = new Button
            {
                Text = "Add Item",
                Location = new Point(420, 8),
                Size = new Size(150, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnAdd.Click += BtnAdd_Click;

            scanPanel.Controls.Add(txtBarcode);
            scanPanel.Controls.Add(btnAdd);

            cartGrid = new DataGridView
            {
                Location = new Point(20, 130),
                Size = new Size(700, 300),
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            cartGrid.Columns.Add("ID", "ID");
            cartGrid.Columns.Add("Name", "Product Name");
            cartGrid.Columns.Add("Price", "Price");
            cartGrid.Columns.Add("Qty", "Qty");
            cartGrid.Columns.Add("Total", "Total");

            btnCheckout = new Button
            {
                Text = "Checkout",
                Location = new Point(20, 450),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(40, 167, 69),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnCheckout.Click += BtnCheckout_Click;

            this.Controls.Add(title);
            this.Controls.Add(scanPanel);
            this.Controls.Add(cartGrid);
            this.Controls.Add(btnCheckout);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string code = txtBarcode.Text.Trim();
            if (string.IsNullOrEmpty(code))
            {
                MessageBox.Show("Enter barcode or SKU.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                var sql = "SELECT id, name, price, stock_qty FROM products WHERE sku=@code OR barcode=@code LIMIT 1";
                var dt = DatabaseHelper.ExecuteQuery(sql, new SqliteParameter("@code", code));
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Product not found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                var row = dt.Rows[0];
                int id = Convert.ToInt32(row["id"]);
                string name = Convert.ToString(row["name"]);
                decimal price = Convert.ToDecimal(row["price"]);
                int stock = Convert.ToInt32(row["stock_qty"]);

                // Check if already in cart
                foreach (DataGridViewRow cartRow in cartGrid.Rows)
                {
                    if (Convert.ToInt32(cartRow.Cells["ID"].Value) == id)
                    {
                        int qty = Convert.ToInt32(cartRow.Cells["Qty"].Value);
                        if (qty + 1 > stock)
                        {
                            MessageBox.Show("Not enough stock.", "Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        cartRow.Cells["Qty"].Value = qty + 1;
                        cartRow.Cells["Total"].Value = (price * (qty + 1)).ToString("F2");
                        return;
                    }
                }
                // Add new row
                if (stock < 1)
                {
                    MessageBox.Show("Out of stock.", "Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                cartGrid.Rows.Add(id, name, price.ToString("F2"), 1, price.ToString("F2"));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to add item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCheckout_Click(object sender, EventArgs e)
        {
            if (cartGrid.Rows.Count == 0)
            {
                MessageBox.Show("Cart is empty.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                using (var tx = conn.BeginTransaction())
                {
                    decimal total = 0;
                    foreach (DataGridViewRow row in cartGrid.Rows)
                    {
                        total += Convert.ToDecimal(row.Cells["Total"].Value);
                    }
                    // Insert sale
                    var cmdSale = conn.CreateCommand();
                    cmdSale.Transaction = tx;
                    cmdSale.CommandText = "INSERT INTO sales (datetime, total, final_amount, user_id) VALUES (@dt, @total, @final, NULL)";
                    cmdSale.Parameters.AddWithValue("@dt", DateTime.Now.ToString("o"));
                    cmdSale.Parameters.AddWithValue("@total", total);
                    cmdSale.Parameters.AddWithValue("@final", total);
                    cmdSale.ExecuteNonQuery();
                    // Get sale id
                    var cmdId = conn.CreateCommand();
                    cmdId.Transaction = tx;
                    cmdId.CommandText = "SELECT last_insert_rowid();";
                    int saleId = Convert.ToInt32(cmdId.ExecuteScalar());
                    // Insert items and update stock
                    foreach (DataGridViewRow row in cartGrid.Rows)
                    {
                        int pid = Convert.ToInt32(row.Cells["ID"].Value);
                        int qty = Convert.ToInt32(row.Cells["Qty"].Value);
                        decimal price = Convert.ToDecimal(row.Cells["Price"].Value);
                        decimal subtotal = price * qty;
                        // Insert sale item
                        var cmdItem = conn.CreateCommand();
                        cmdItem.Transaction = tx;
                        cmdItem.CommandText = "INSERT INTO sale_items (sale_id, product_id, quantity, subtotal) VALUES (@sid, @pid, @qty, @sub)";
                        cmdItem.Parameters.AddWithValue("@sid", saleId);
                        cmdItem.Parameters.AddWithValue("@pid", pid);
                        cmdItem.Parameters.AddWithValue("@qty", qty);
                        cmdItem.Parameters.AddWithValue("@sub", subtotal);
                        cmdItem.ExecuteNonQuery();
                        // Update stock
                        var cmdStock = conn.CreateCommand();
                        cmdStock.Transaction = tx;
                        cmdStock.CommandText = "UPDATE products SET stock_qty = stock_qty - @qty WHERE id=@id";
                        cmdStock.Parameters.AddWithValue("@qty", qty);
                        cmdStock.Parameters.AddWithValue("@id", pid);
                        cmdStock.ExecuteNonQuery();
                    }
                    tx.Commit();
                    MessageBox.Show("Sale completed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cartGrid.Rows.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Checkout failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}