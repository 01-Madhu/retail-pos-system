using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using RetailPOS.Database;
using RetailPOS.Utils;

namespace RetailPOS
{
    public class LoginForm : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnCancel;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Retail POS - Login";
            this.Size = new Size(400, 300);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Title
            var lblTitle = new Label
            {
                Text = "RETAIL POS SYSTEM",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 122, 204),
                AutoSize = false,
                Size = new Size(350, 40),
                Location = new Point(25, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Username
            var lblUsername = new Label
            {
                Text = "Username:",
                Font = new Font("Segoe UI", 10),
                Location = new Point(50, 80),
                Size = new Size(80, 25)
            };

            txtUsername = new TextBox
            {
                Location = new Point(50, 105),
                Size = new Size(250, 30),
                Font = new Font("Segoe UI", 10)
            };

            // Password
            var lblPassword = new Label
            {
                Text = "Password:",
                Font = new Font("Segoe UI", 10),
                Location = new Point(50, 145),
                Size = new Size(80, 25)
            };

            txtPassword = new TextBox
            {
                Location = new Point(50, 170),
                Size = new Size(250, 30),
                Font = new Font("Segoe UI", 10),
                UseSystemPasswordChar = true
            };

            // Buttons
            btnLogin = new Button
            {
                Text = "LOGIN",
                Location = new Point(50, 220),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnLogin.Click += BtnLogin_Click;

            btnCancel = new Button
            {
                Text = "CANCEL",
                Location = new Point(180, 220),
                Size = new Size(120, 35),
                BackColor = Color.FromArgb(108, 117, 125),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10)
            };
            btnCancel.Click += (s, e) => Application.Exit();

            // Demo info
            var lblDemo = new Label
            {
                Text = "Demo: admin / 1234",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.Gray,
                Location = new Point(50, 260),
                Size = new Size(250, 20)
            };

            // Add controls to form
            this.Controls.Add(lblTitle);
            this.Controls.Add(lblUsername);
            this.Controls.Add(txtUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnCancel);
            this.Controls.Add(lblDemo);

            // Set focus to username field
            txtUsername.Focus();
            this.AcceptButton = btnLogin;
            this.CancelButton = btnCancel;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // For demo purposes - hardcoded check
                if (username == "admin" && password == "1234")
                {
                    this.Hide();
                    var dashboard = new MainDashboard(1, "admin", "Admin");
                    dashboard.Show();
                }
                else
                {
                    // Database authentication
                    string passwordHash = HashHelper.ComputeSha256Hash(password);

                    string sql = "SELECT id, username, role FROM users WHERE username = @username AND password_hash = @password";

                    var parameters = new[]
                    {
                        new SqliteParameter("@username", username),
                        new SqliteParameter("@password", passwordHash)
                    };

                    var dt = DatabaseHelper.ExecuteQuery(sql, parameters);

                    if (dt.Rows.Count > 0)
                    {
                        var row = dt.Rows[0];
                        int userId = Convert.ToInt32(row["id"]);
                        string userRole = row["role"].ToString();

                        this.Hide();
                        var dashboard = new MainDashboard(userId, username, userRole);
                        dashboard.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password", "Authentication Failed",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Login failed: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}