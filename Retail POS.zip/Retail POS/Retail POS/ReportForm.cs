using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace RetailPOS
{
    public class ReportForm : Form
    {
        private string _role;
        private DataGridView dataGridView1;
        private Button btnExportCsv;

        public ReportForm(string role)
        {
            _role = role;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Sales Reports";
            this.BackColor = Color.White;

            var title = new Label
            {
                Text = "Sales Reports & Analytics",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            var reportPanel = new Panel
            {
                Location = new Point(20, 70),
                Size = new Size(700, 400),
                BorderStyle = BorderStyle.FixedSingle
            };

            dataGridView1 = new DataGridView
            {
                Location = new Point(10, 50),
                Size = new Size(680, 300),
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false
            };

            dataGridView1.Columns.Add("Date", "Date");
            dataGridView1.Columns.Add("SaleID", "Sale ID");
            dataGridView1.Columns.Add("Customer", "Customer");
            dataGridView1.Columns.Add("Amount", "Amount");
            dataGridView1.Columns.Add("Items", "Items");

            // Sample report data
            dataGridView1.Rows.Add("2024-01-15", "S001", "Walk-in Customer", "GHS 250.00", "3");
            dataGridView1.Rows.Add("2024-01-15", "S002", "John Doe", "GHS 180.50", "2");
            dataGridView1.Rows.Add("2024-01-14", "S003", "Jane Smith", "GHS 420.75", "5");
            dataGridView1.Rows.Add("2024-01-13", "S004", "Mike Johnson", "GHS 320.25", "4");

            var summaryLabel = new Label
            {
                Text = "Sales Summary - Last 7 Days",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true
            };

            var totalLabel = new Label
            {
                Text = "Total Sales: GHS 1,171.50",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(10, 360),
                AutoSize = true
            };

            btnExportCsv = new Button
            {
                Text = "Export to CSV",
                Location = new Point(550, 360),
                Size = new Size(120, 32),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnExportCsv.Click += btnExportCsv_Click;

            reportPanel.Controls.Add(summaryLabel);
            reportPanel.Controls.Add(dataGridView1);
            reportPanel.Controls.Add(totalLabel);
            reportPanel.Controls.Add(btnExportCsv);

            this.Controls.Add(title);
            this.Controls.Add(reportPanel);
        }

        /// <summary>
        /// Handles Export to CSV button click. Saves DataGridView contents to a CSV file.
        /// </summary>
        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            // FEATURE: Export DataGridView contents to CSV file
            // DEVELOPER: Madhushan Sangaralingam
            // CONTEXT: Retail POS & Inventory Manager - ReportForm.cs
            // See master prompt for requirements.

            try
            {
                // 1. Use SaveFileDialog for user to choose file location
                using (var sfd = new SaveFileDialog())
                {
                    string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    sfd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                    sfd.FileName = $"SalesReport_{timestamp}.csv";
                    sfd.Title = "Export Sales Report to CSV";

                    if (sfd.ShowDialog() != DialogResult.OK)
                        return;

                    // 2. Build CSV content
                    var sb = new StringBuilder();

                    // 3. Write column headers
                    for (int i = 0; i < dataGridView1.Columns.Count; i++)
                    {
                        sb.Append(EscapeCsv(dataGridView1.Columns[i].HeaderText));
                        if (i < dataGridView1.Columns.Count - 1)
                            sb.Append(",");
                    }
                    sb.AppendLine();

                    // 4. Write row data
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        // 7. Skip new/empty rows
                        if (row.IsNewRow) continue;
                        bool allEmpty = true;
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            var val = row.Cells[i].Value;
                            if (val != null && !string.IsNullOrWhiteSpace(val.ToString()))
                            {
                                allEmpty = false;
                                break;
                            }
                        }
                        if (allEmpty) continue;

                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            var val = row.Cells[i].Value;
                            sb.Append(EscapeCsv(val?.ToString() ?? ""));
                            if (i < dataGridView1.Columns.Count - 1)
                                sb.Append(",");
                        }
                        sb.AppendLine();
                    }

                    // 8. Write to file with UTF-8 encoding and error handling
                    try
                    {
                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                        MessageBox.Show($"Export successful!\nFile saved: {sfd.FileName}", "Export to CSV", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to export CSV: {ex.Message}", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Escapes a value for CSV output. Wraps in double quotes if needed and doubles internal quotes.
        /// </summary>
        private static string EscapeCsv(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            bool mustQuote = value.Contains(",") || value.Contains("\"") || value.Contains("\n") || value.Contains("\r");
            if (mustQuote)
            {
                value = value.Replace("\"", "\"\"");
                return $"\"{value}\"";
            }
            return value;
        }
    }
}