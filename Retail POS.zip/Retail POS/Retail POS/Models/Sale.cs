using System;

namespace RetailPOS.Models
{
    /// <summary>
    /// Represents a sale stored in the `sales` table.
    /// Properties map directly to the database column names.
    /// </summary>
    public class Sale
    {
        /// <summary>
        /// Primary key identifier (maps to `id` INTEGER PRIMARY KEY).
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Date/time of the sale (maps to `datetime` TEXT).
        /// </summary>
        public string datetime { get; set; }

        /// <summary>
        /// Total before discounts and tax (maps to `total` REAL).
        /// </summary>
        public double total { get; set; }

        /// <summary>
        /// Discount amount (maps to `discount` REAL).
        /// </summary>
        public double discount { get; set; }

        /// <summary>
        /// Tax amount (maps to `tax` REAL).
        /// </summary>
        public double tax { get; set; }

        /// <summary>
        /// Final amount after discount & tax (maps to `final_amount` REAL).
        /// </summary>
        public double final_amount { get; set; }

        /// <summary>
        /// ID of the user who processed the sale (maps to `user_id` INTEGER).
        /// </summary>
        public int user_id { get; set; }
    }
}
