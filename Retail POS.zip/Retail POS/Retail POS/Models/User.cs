using System;

namespace RetailPOS.Models
{
    /// <summary>
    /// Represents a user account stored in the `users` table.
    /// Properties map directly to the database column names.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Primary key identifier (maps to `id` INTEGER PRIMARY KEY).
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Username (maps to `username` TEXT).
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// SHA256 password hash (maps to `password_hash` TEXT).
        /// </summary>
        public string password_hash { get; set; }

        /// <summary>
        /// Role name (e.g., Admin, Manager, Cashier) (maps to `role` TEXT).
        /// </summary>
        public string role { get; set; }
    }
}
