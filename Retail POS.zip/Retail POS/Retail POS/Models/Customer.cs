using System;

namespace RetailPOS.Models
{
    /// <summary>
    /// Represents a customer stored in the `customers` table.
    /// Properties map directly to the database column names.
    /// </summary>
    public class Customer
    {
        /// <summary>
        /// Primary key identifier (maps to `id` INTEGER PRIMARY KEY).
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Customer name (maps to `name` TEXT).
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Phone number (maps to `phone` TEXT).
        /// </summary>
        public string phone { get; set; }

        /// <summary>
        /// Email address (maps to `email` TEXT).
        /// </summary>
        public string email { get; set; }

        /// <summary>
        /// Loyalty points (maps to `loyalty_points` INTEGER).
        /// </summary>
        public int loyalty_points { get; set; }
    }
}
