using System;

namespace RetailPOS.Models
{
    /// <summary>
    /// Represents a product stored in the `products` table.
    /// Properties map directly to the database column names.
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Primary key identifier (maps to `id` INTEGER PRIMARY KEY).
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Product name (maps to `name` TEXT).
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Category (maps to `category` TEXT).
        /// </summary>
        public string category { get; set; }

        /// <summary>
        /// SKU (maps to `sku` TEXT).
        /// </summary>
        public string sku { get; set; }

        /// <summary>
        /// Barcode (maps to `barcode` TEXT).
        /// </summary>
        public string barcode { get; set; }

        /// <summary>
        /// Unit price (maps to `price` REAL).
        /// </summary>
        public double price { get; set; }

        /// <summary>
        /// Stock quantity (maps to `stock_qty` INTEGER).
        /// </summary>
        public int stock_qty { get; set; }

        /// <summary>
        /// Low stock alert threshold (maps to `low_stock_alert` INTEGER).
        /// </summary>
        public int low_stock_alert { get; set; }
    }
}
